# Subprogramas -----

# Recebendo inputs
def recebeParametros():

    # Criando dicionário que servirá de armazenamento dos dados de entrada
    dadosEntrada = dict()

    # Recebendo nome do arquivo
    dadosEntrada["arquivo"]  = str(input("Insira o endereço do arquivo de texto:"))

    # Recebendo palavra a ser buscada no arquivo
    dadosEntrada["palavra"]  = str(input("Insira a palavra a ser buscada no arquivo de texto:"))

    # Retornando resultados ao usuário
    return(dadosEntrada)

# Processamento: busca da palavra no corpo do texto contido no arquivo
def buscaPalavra(palavra, nomeArquivo):

    # Abrindo arquivo de texto
    texto = open(nomeArquivo, "r")

    # Inicializando contador de linhas
    indice = 1

    # Lendo linha-a-linha o texto e buscando a palavra solicitada pelo usuário
    for linha in texto:

        # Removendo pontos, vírgulas e caracteres de retorno
        linha = linha.replace(".", "")
        linha = linha.replace(",", "")
        linha = linha.replace("\n", "")

        # Separando as palavras da linha
        listaPalavras = linha.split(" ")

        # Iterando sobre as palavras da linha
        for indicePalavra in range(len(listaPalavras)):

            # Encontrando as ocorrências da palavra nesta linha
            if listaPalavras[indicePalavra] == palavra:

                # Imprimindo os índices das palavras encontradas
                print(f"\tLinha {indice}, Palavra {indicePalavra + 1} nesta linha!")
        
        # Atualizando contador de linhas
        indice = indice + 1

    return(None)

# Fim dos subprogramas -----

# Programa Principal

# Recebendo nome do arquivo e palavra a ser encontrada
dadosEntrada = recebeParametros()

# Processamento do texto: busca da palavra
print(f"Ocorrências da palavra {dadosEntrada['palavra']} no arquivo {dadosEntrada['arquivo']}:")
buscaPalavra(palavra = dadosEntrada["palavra"], nomeArquivo = dadosEntrada["arquivo"])