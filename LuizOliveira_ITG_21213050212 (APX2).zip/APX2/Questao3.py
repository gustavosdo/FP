# Subprogramas -----

# Função que copia os dados de um arquivo para outro (levemente modificada do slide 49 da aula 9)
def copiaArquivo(arquivoOriginal):

    # Lendo arquivo original
    original = open(arquivoOriginal, "r")
    
    # Definindo endereço do novo arquivo
    arquivoNovo = "copia_" + arquivoOriginal

    # Abrindo arquivo para escrita
    destino = open(arquivoNovo, "w")
    
    # Copiando linha-a-linha
    for linha in original:
        destino.write(linha)
    
    # Fechando arquivos
    destino.close()
    original.close()

    # Retorna endereço da cópia do arquivo
    return(arquivoNovo)

# Essa função imprime todos os dados
def imprime(arquivo, remocao = False):
    
    # Lendo os arquivos
    dados = open(arquivo, "r")

    # Caso tenha sido realizada a remoção, deixar explícito na impressão
    if (remocao):
        print("Conteúdo do Arquivo "+arquivo+" após eventuais remoções:")
    else:
        print("Conteúdo do Arquivo "+arquivo+":")

    # Imprimindo dados linha por linha
    for linha in dados:
        print("\t\t", linha, end = "")
    print("\n")

    # Fechando arquivo
    dados.close()

    # Retorna ao programa principal
    return None

# Função que remove do arquivo as linhas que contenham um ou mais números primos
def removeNumeros(arquivo):

    # Copiando os números orginais para um arquivo auxiliar
    arquivoAux = copiaArquivo(arquivo)

    # Arquivo original (copiado)
    numeros = open(arquivoAux, "r")

    # Sobrescrevendo arquivo de dados com o resultado
    numerosAposRemocao = open(arquivo, "w")

    for linha in numeros:
        if (not(contemNumerosPrimos(linha))):
            numerosAposRemocao.write(linha)

    # Fechando arquivos
    numerosAposRemocao.close()
    numeros.close()

    # Retornando ao programa principal
    return(None)

# Função para determinar se a linha contém números primos
def contemNumerosPrimos(linha):

    # Obtendo lista de números na linha
    numeros = [int(v) for v in linha.split()]

    # Inicializando variável que define a primalidade dos números na linha
    contemPrimo = False

    # Contador de números processados
    indice = 0

    # Iterando sobre os números da linha:
    while (not(contemPrimo) and indice < len(numeros)):
        # Testando a primalidade de cada número
        contemPrimo = testePrimalidade(numeros[indice])
        indice = indice + 1

    # Retorna resultado do teste de primalidade da linha
    return contemPrimo

# Testando primalidade de um número (https://en.wikipedia.org/wiki/Primality_test#Simple_methods)
def testePrimalidade(num):

    # Casos triviais
    if (num <= 1):
        return False
    elif (num <= 3):
        return True

    # Checando divisão pelos primeiros primos para otimizar o loop a seguir:
    if (num % 2 == 0 or num % 3 == 0):
        return False

    # Checando os demais números até sqrt(num)
    divisor = 5
    while (divisor * divisor <= num):

        if (num % divisor == 0 or num % (divisor + 2) == 0):
            return False

        divisor = divisor + 6

    return True

# Fim dos subprogramas -----

# Programa principal

# Recebendo nome do arquivo que contém os pontos
arquivo = str(input("Entre com o nome do arquivo que contém os números:"))

# Imprimindo conteúdo do arquivo
imprime(arquivo)

# Removendo os pontos que estiverem dentro dos círculos
removeNumeros(arquivo)

# Lendo os dados após a remoção dos pontos e imprimindo
imprime(arquivo, remocao = True)