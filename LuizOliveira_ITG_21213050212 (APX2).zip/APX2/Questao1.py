import struct

# Estrutura do registro dentro do arquivo binário
Conversao = struct.Struct("20s 20s f")

# Subprogramas -----

# Solução da questão 1: codificação que gera um arquivo .bin a partir do arquivo .txt
def geraBinarioMoedas():

    # Abrindo (ou criando) arquivo binário para salvar os dados
    with open("conversoes.bin", "wb") as arquivoBinario:

        # Abrindo o arquivo txt original com os dados
        with open("conversoes.txt", "r") as arquivoTexto:

            # Lendo cada linha dos dados
            for linha in arquivoTexto.readlines():

                # Obtendo as strings que definem a bandeira e a taxa do cartão
                moeda1, moeda2, conversao = linha.strip().split("#")

                # Empacotando e codificando em binário os dados
                bloco = Conversao.pack(moeda1.encode("utf-8"), moeda2.encode("utf-8"), float(conversao))

                # Escrevendo os dados processados no arquivo binário
                arquivoBinario.write(bloco)

    # Finalizando o programa
    return(None)

# Função para determinar se uma entrada é float
def verificaFloat(entrada):

    # Contadores
    contadorPonto = 0
    contadorNaoNumeros = 0

    # Vamos analisar cada caractere da entrada inserida
    for char in entrada:

        # Um float é composto de apenas dígitos numéricos, um "." e nenhum caractere não-numérico (p.ex.: alfabeto)
        if (char >= '0' and char <= '9'):
            pass
        elif (char == "."):
            contadorPonto = contadorPonto + 1
        else:
            contadorNaoNumeros = contadorNaoNumeros + 1

    # Aplicando os vínculos aos contadores e retornando o resultado negativo ao usuário
    if (contadorPonto > 1) or (contadorNaoNumeros > 0):
        return False

    # Retornando resultado positivo caso nenhum erro seja encontrado
    return True

# Função que busca a taxa de conversão entre as moedas
def buscaTaxa(conversoes, moeda1, moeda2):

    # Inicializando resultado: valor nulo servirá de teste no Programa Principal
    taxa = 0

    # Determinando número de registros contidos no arquivo
    arquivo = conversoes.read()
    numeroRegistros = len(arquivo)/Conversao.size

    # Retornando cursor ao início do arquivo
    conversoes.seek(0)

    # Lendo as taxas disponíveis e buscando por aquele que corresponde ao nome inserido pelo usuário
    for indice in range(int(numeroRegistros)):
        bloco = conversoes.read(Conversao.size)
        campos = Conversao.unpack(bloco)
        if (campos[0].decode("utf-8").rstrip(chr(0)) == moeda2 and campos[1].decode("utf-8").rstrip(chr(0)) == moeda1):
            taxa = 1/campos[2]
        elif (campos[0].decode("utf-8").rstrip(chr(0)) == moeda1 and campos[1].decode("utf-8").rstrip(chr(0)) == moeda2):
            taxa = campos[2]

    return(taxa)

def calculaValorTotal(moeda1, moeda2, taxa, valor):

    # Dicionário de nomes e siglas das moedas
    siglaNomes = {"real" : "BRL", "euro": "EUR", "dolar" : "USD"}

    # Calculando valor após conversão
    valorTotal = valor * taxa

    # Retornando resultado ao usuário
    print(f"Você pagará {valorTotal:.2f} {siglaNomes[moeda2]} por {valor:.2f} {siglaNomes[moeda1]}")
    return(None)

# Fim dos Subprogramas -----

# Programa principal -----

# Gerando arquivo binário
geraBinarioMoedas()

# Lendo o arquivo binário a ser utilizado
arquivoBinario = input()

# Recebendo o nome da moeda a ser convertida
moeda1 = input()

# Recebendo o nome da moeda para o qual será convertido o valor
moeda2 = input()

# Recebendo o valor a ser convertido
valor = input()

# Testando se arquivo binário existe
try:
    with open(arquivoBinario, "rb") as conversoes:

        # Lendo as moedas disponíveis e verificando validade dos nomes inserido pelo usuário
        taxa = buscaTaxa(conversoes, moeda1, moeda2)
        if (taxa != 0):

            # Testando se a entrada de valor é float
            if (verificaFloat(valor)):
                valor = float(valor)

                # Calculando valor convertido
                calculaValorTotal(moeda1, moeda2, taxa, valor)
            else:
                print("você não colocou um valor correto")
        else:
            print("Alguma moeda não consta")

except IOError:
    print("Um dos arquivos não foi encontrado ou você digitou errado.")